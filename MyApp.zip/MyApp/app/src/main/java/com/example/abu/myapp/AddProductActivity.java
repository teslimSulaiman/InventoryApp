package com.example.abu.myapp;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.app.LoaderManager;
import android.content.CursorLoader;
import android.content.Loader;
import android.os.Build;
import android.os.ParcelFileDescriptor;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ShareCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.abu.myapp.data.PhoneContract.PhoneEntry;

import java.io.FileDescriptor;
import java.io.IOException;

public class AddProductActivity extends AppCompatActivity {

    private static final String LOG_TAG = AddProductActivity.class.getSimpleName();
    private static final int PICK_IMAGE_REQUEST = 0;
    private ImageView mImageView;
    private Button selectImageButton;
    private Uri mUri;
    private Bitmap mBitmap;
    private static final int EXISTING_PHONE_LOADER = 0;

    /**
     * EditText field to enter the phone's name
     */
    private EditText mProductName;

    /**
     * EditText field to enter the phone's price
     */
    private EditText mProductPrice;

    /**
     * EditText field to enter the phone's quantity
     */
    private EditText mQuantity;

    /**
     * EditText field to enter the phone's supplier email
     */
    private EditText mEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_product);

        mProductName = (EditText) findViewById(R.id.product_name);
        mProductPrice = (EditText) findViewById(R.id.product_price);
        mQuantity = (EditText) findViewById(R.id.quantity);
        mEmail = (EditText) findViewById(R.id.supplier_email);
        mImageView = (ImageView) findViewById(R.id.image);
        selectImageButton = (Button) findViewById(R.id.select_image);
        selectImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openImageSelector(view);
            }
        });
    }

    public void openImageSelector(View view) {
        Intent intent;
        if (Build.VERSION.SDK_INT < 19) {
            intent = new Intent(Intent.ACTION_GET_CONTENT);
        } else {
            intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
        }

        intent.setType("image/*");
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE_REQUEST);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent resultData) {
        // The ACTION_OPEN_DOCUMENT intent was sent with the request code READ_REQUEST_CODE.
        // If the request code seen here doesn't match, it's the response to some other intent,
        // and the below code shouldn't run at all.

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == Activity.RESULT_OK) {
            // The document selected by the user won't be returned in the intent.
            // Instead, a URI to that document will be contained in the return intent
            // provided to this method as a parameter.  Pull that uri using "resultData.getData()"

            if (resultData != null) {
                mUri = resultData.getData();
                Log.i(LOG_TAG, "Uri: " + mUri.toString());

                //mTextView.setText(mUri.toString());
                mImageView.setImageBitmap(getBitmapFromUri(mUri));
            }
        }
    }

    private Bitmap getBitmapFromUri(Uri uri) {
        ParcelFileDescriptor parcelFileDescriptor = null;
        try {
            parcelFileDescriptor =
                    getContentResolver().openFileDescriptor(uri, "r");
            FileDescriptor fileDescriptor = parcelFileDescriptor.getFileDescriptor();
            Bitmap image = BitmapFactory.decodeFileDescriptor(fileDescriptor);
            parcelFileDescriptor.close();
            return image;
        } catch (Exception e) {
            Log.e(LOG_TAG, "Failed to load image.", e);
            return null;
        } finally {
            try {
                if (parcelFileDescriptor != null) {
                    parcelFileDescriptor.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
                Log.e(LOG_TAG, "Error closing ParcelFile Descriptor");
            }
        }
    }

    private void savePhone() {
        // Read from input fields
        // Use trim to eliminate leading or trailing white space
        String name = mProductName.getText().toString().trim();
        String price = mProductPrice.getText().toString().trim();
        String quantity = mQuantity.getText().toString().trim();
        String email = mEmail.getText().toString().trim();
        String uri = mUri.toString();

        // Create a ContentValues object where column names are the keys,
        // and phone attributes from the editor are the values.
        ContentValues values = new ContentValues();
        values.put(PhoneEntry.COLUMN_PHONE_NAME, name);
        values.put(PhoneEntry.COLUMN_PHONE_PRICE, price);
        values.put(PhoneEntry.COLUMN_PHONE_QUANTITY, quantity);
        values.put(PhoneEntry.COLUMN_SUPPLIER_EMAIL, email);
        values.put(PhoneEntry.COLUMN_IMAGE_PATH, uri);

        // This is a NEW phone, so insert a new phone into the provider,
        // returning the content URI for the new phone.
        Uri newUri = getContentResolver().insert(PhoneEntry.CONTENT_URI, values);

        // Show a toast message depending on whether or not the insertion was successful.
        if (newUri == null) {
            // If the new content URI is null, then there was an error with insertion.
            Toast.makeText(this, getString(R.string.insert_phone_failed),
                    Toast.LENGTH_SHORT).show();
        } else {
            // Otherwise, the insertion was successful and we can display a toast.
            Toast.makeText(this, getString(R.string.insert_phone_successful),
                    Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_editor, menu);
        return true;
    }

    /**
     * This method is called after invalidateOptionsMenu(), so that the
     * menu can be updated (some menu items can be hidden or made visible).
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // User clicked on a menu option in the app bar overflow menu
        switch (item.getItemId()) {
            // Respond to a click on the "Save" menu option
            case R.id.action_save:
                // Save phone to database
                if (validateInputs(mProductName, mProductPrice, mQuantity, mEmail, mUri)) {
                    savePhone();
                    // Exit activity
                    finish();
                    return true;
                }
                Toast.makeText(this, getString(R.string.fill_all_fields),
                        Toast.LENGTH_LONG).show();
                return true;

        }
        return super.onOptionsItemSelected(item);
    }

    public boolean validateInputs(EditText nameEditText, EditText priceEditText, EditText quantityEditText,
                                  EditText emailEditText, Uri uri) {
        if (uri == null) return false;
        String name = nameEditText.getText().toString().trim();
        String price = priceEditText.getText().toString().trim();
        String quantity = quantityEditText.getText().toString().trim();
        String email = emailEditText.getText().toString().trim();

        if (TextUtils.isEmpty(name)) return false;
        if (TextUtils.isEmpty(price)) return false;
        if (TextUtils.isEmpty(quantity)) return false;
        if (TextUtils.isEmpty(email)) return false;

        return true;
    }

}
