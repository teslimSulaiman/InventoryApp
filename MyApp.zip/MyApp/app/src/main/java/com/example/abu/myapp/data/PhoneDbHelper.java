package com.example.abu.myapp.data;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import com.example.abu.myapp.data.PhoneContract.PhoneEntry;

public class PhoneDbHelper extends SQLiteOpenHelper {

    public static final String LOG_TAG = PhoneContract.class.getSimpleName();

    /**
     * Name of the database file
     */
    private static final String DATABASE_NAME = "phone_mart.db";

    /**
     * Database version. If you change the database schema, you must increment the database version.
     */
    private static final int DATABASE_VERSION = 1;

    private static final String SQL_CREATE_TABLE = "CREATE TABLE " + PhoneEntry.TABLE_NAME + " ("
            + PhoneEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
            + PhoneEntry.COLUMN_PHONE_NAME + " TEXT, "
            + PhoneEntry.COLUMN_PHONE_PRICE + " REAL NOT NULL DEFAULT 0.0 , "
            + PhoneEntry.COLUMN_PHONE_QUANTITY + " INTEGER NOT NULL DEFAULT 0 , "
            + PhoneEntry.COLUMN_PHONE_REMAINING + " INTEGER NOT NULL DEFAULT 0 , "
            + PhoneEntry.COLUMN_SUPPLIER_EMAIL + " TEXT, "
            + PhoneEntry.COLUMN_IMAGE_PATH + " TEXT " + " )";

    private static final String SQL_DELETE_ENTRIES =
            "DROP TABLE IF EXISTS " + PhoneEntry.TABLE_NAME;

    /**
     * Constructs a new instance of {@link PhoneDbHelper}.
     *
     * @param context of the app
     */
    public PhoneDbHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }


    /**
     * This is called when the database is created for the first time.
     */
    @Override
    public void onCreate(SQLiteDatabase db) {

        // Execute the SQL statement
        db.execSQL(SQL_CREATE_TABLE);
    }

    /**
     * This is called when the database needs to be upgraded.
     */
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL(SQL_DELETE_ENTRIES);
        onCreate(db);
    }

}