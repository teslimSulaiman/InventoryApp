package com.example.abu.myapp;

import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CursorAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.abu.myapp.data.PhoneContract;
import com.example.abu.myapp.data.PhoneContract.PhoneEntry;

public class PhoneCursorAdapter extends CursorAdapter {

    public PhoneCursorAdapter(Context context, Cursor c) {
        super(context, c, 0 /* flags */);
    }

    @Override
    public View newView(Context context, Cursor cursor, ViewGroup parent) {
        return LayoutInflater.from(context).inflate(R.layout.list_item, parent, false);
    }

    @Override
    public void bindView(View view, final Context context, final Cursor cursor) {

        // Find individual views that we want to modify in the list item layout
        TextView productName = (TextView) view.findViewById(R.id.product_name);
        TextView productPrice = (TextView) view.findViewById(R.id.product_price);
        final TextView quantityTextView = (TextView) view.findViewById(R.id.quantity);
        final TextView amountSoldTextView = (TextView) view.findViewById(R.id.amount_sold);
        Button sellButton = (Button) view.findViewById(R.id.sell_button);
        LinearLayout parentView = (LinearLayout) view.findViewById(R.id.list_product_view);

        // Find the columns of phone attributes that we're interested in
        int nameColumnIndex = cursor.getColumnIndex(PhoneEntry.COLUMN_PHONE_NAME);
        int priceColumnIndex = cursor.getColumnIndex(PhoneEntry.COLUMN_PHONE_PRICE);
        int quantityColumnIndex = cursor.getColumnIndex(PhoneEntry.COLUMN_PHONE_QUANTITY);
        int amountSoldColumnIndex = cursor.getColumnIndex(PhoneEntry.COLUMN_PHONE_REMAINING);
        int idColumnIndex = cursor.getColumnIndex(PhoneEntry._ID);

        // Read the attributes from the Cursor for the current item
        final int rowId = cursor.getInt(idColumnIndex);

        // Read the phone attributes from the Cursor for the current phone
        String phoneName = cursor.getString(nameColumnIndex);
        double phonePrice = cursor.getDouble(priceColumnIndex);
        int phoneQuantity = cursor.getInt(quantityColumnIndex);
        int phoneQuantitySold = cursor.getInt(amountSoldColumnIndex);
        String displayPrice = Double.toString(phonePrice);
        String displayQuantity = Integer.toString(phoneQuantity);
        String displayQuantitySold = Integer.toString(phoneQuantitySold);

        // Update the TextViews with the attributes for the current phone
        productName.setText(phoneName);
        productPrice.setText(displayPrice);
        quantityTextView.setText(displayQuantity);
        amountSoldTextView.setText(displayQuantitySold);

        parentView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Open Editor activity
                Intent intent = new Intent(context, DetailActivity.class);

                // Form the content URI that represents clicked phone
                Uri currentProductUri = ContentUris.withAppendedId(PhoneEntry.CONTENT_URI,
                        rowId);

                // Set the URI on the data field of the intent
                intent.setData(currentProductUri);
                context.startActivity(intent);
            }
        });

        sellButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int quantityInStock = Integer.parseInt(quantityTextView.getText().toString());
                int quantitySold = Integer.parseInt(amountSoldTextView.getText().toString());
                if (quantityInStock > 0) {
                    quantityInStock = quantityInStock - 1;
                    quantitySold = quantitySold + 1;
                    String quantityString = Integer.toString(quantityInStock);
                    String soldString = Integer.toString(quantitySold);

                    ContentValues values = new ContentValues();
                    values.put(PhoneEntry.COLUMN_PHONE_QUANTITY, quantityInStock);
                    values.put(PhoneEntry.COLUMN_PHONE_REMAINING, quantitySold);
                    Uri currentProductUri = ContentUris.withAppendedId(PhoneEntry.CONTENT_URI,
                            rowId);
                    int rowsAffected = context.getContentResolver().update(currentProductUri, values,
                            null, null);
                    if (rowsAffected != 0) {

                        // update text view if db update is successful
                        quantityTextView.setText(quantityString);
                        amountSoldTextView.setText(soldString);
                    } else {

                    }
                }
            }
        });
    }

    @Override
    protected void onContentChanged() {
        super.onContentChanged();
        notifyDataSetChanged();
    }
}