package com.example.abu.myapp;

import android.app.LoaderManager;
import android.content.ContentValues;
import android.content.CursorLoader;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.Loader;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.abu.myapp.data.PhoneContract.PhoneEntry;

import java.io.File;
import java.io.FileDescriptor;
import java.io.IOException;

public class DetailActivity extends AppCompatActivity implements
        LoaderManager.LoaderCallbacks<Cursor> {

    private static final int EXISTING_PHONE_LOADER = 0;
    private static final String LOG_TAG = "errors";
    private TextView textViewProductName, textViewProductPrice, textViewProductQty, textViewProductSold;
    Button upButton, downButton, doneButton, cancelButton, orderButton, deleteButton, editQuantityButton;
    private ImageView imageView;
    private EditText editTextQuantity;
    private Uri mCurrentPhoneUri;
    private String supplierEmail;
    private String phoneName;
    private int phoneQuantity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        textViewProductName = (TextView) findViewById(R.id.product_name);
        textViewProductPrice = (TextView) findViewById(R.id.product_price);
        textViewProductQty = (TextView) findViewById(R.id.quantity);
        textViewProductSold = (TextView) findViewById(R.id.quantity_sold);
        imageView = (ImageView) findViewById(R.id.phone_image);
        upButton = (Button) findViewById(R.id.addOne);
        downButton = (Button) findViewById(R.id.minusOne);
        doneButton = (Button) findViewById(R.id.done);
        cancelButton = (Button) findViewById(R.id.cancel);
        orderButton = (Button) findViewById(R.id.order_phone);
        deleteButton = (Button) findViewById(R.id.delete_phone);
        editQuantityButton = (Button) findViewById(R.id.edit_quantity_button);
        editTextQuantity = (EditText) findViewById(R.id.edit_quantity);
        final LinearLayout upContainer = (LinearLayout) findViewById(R.id.upContainer);
        final LinearLayout doneContainer = (LinearLayout) findViewById(R.id.doneContainer);

        Intent intent = getIntent();
        mCurrentPhoneUri = intent.getData();
        getLoaderManager().initLoader(EXISTING_PHONE_LOADER, null, this);

        upButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                int quantity = Integer.parseInt(editTextQuantity.getText().toString());
                quantity++;
                editTextQuantity.setText(Integer.toString(quantity));

            }
        });

        downButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                int quantity = Integer.parseInt(editTextQuantity.getText().toString());
                if (quantity > 0)
                    quantity--;
                editTextQuantity.setText(Integer.toString(quantity));
            }
        });

        cancelButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                setLayoutsToHide(upContainer, doneContainer);
                finish();
            }
        });

        editQuantityButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                String displayQuantity = Integer.toString(phoneQuantity);
                editTextQuantity.setText(displayQuantity);
                setLayoutsToVisible(upContainer, doneContainer);
            }
        });

        doneButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                int quantity = Integer.parseInt(editTextQuantity.getText().toString());
                savePhone(quantity);
                finish();
            }
        });

        deleteButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                showDeleteConfirmationDialog();
            }
        });

        orderButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_SENDTO);
                intent.setData(Uri.parse("mailto:")); // only email apps should handle this
                intent.putExtra(Intent.EXTRA_EMAIL, new String[]{supplierEmail});
                intent.putExtra(Intent.EXTRA_SUBJECT, "ORDER MORE PHONE");
                intent.putExtra(Intent.EXTRA_TEXT, "This is an order on " + "\n" + "Product name: " + phoneName);
                if (intent.resolveActivity(getPackageManager()) != null) {
                    startActivity(intent);
                }
            }
        });
    }

    private void deletePhone() {
        if (mCurrentPhoneUri != null) {
            // Call the ContentResolver to delete the phone at the given content URI.
            // Pass in null for the selection and selection args because the mCurrentPhoneUri
            // content URI already identifies the phone that we want.
            int rowsDeleted = getContentResolver().delete(mCurrentPhoneUri, null, null);

            // Show a toast message depending on whether or not the delete was successful.
            if (rowsDeleted == 0) {
                // If no rows were deleted, then there was an error with the delete.
                Toast.makeText(this, getString(R.string.delete_phone_failed),
                        Toast.LENGTH_SHORT).show();
            } else {
                // Otherwise, the delete was successful and we can display a toast.
                Toast.makeText(this, getString(R.string.delete_phone_successful),
                        Toast.LENGTH_SHORT).show();
            }
        }

        // Close the activity
        finish();
    }

    private void savePhone(int quantity) {
        ContentValues values = new ContentValues();
        values.put(PhoneEntry.COLUMN_PHONE_QUANTITY, quantity);
        int rowsAffected = getContentResolver().update(mCurrentPhoneUri, values, null, null);
    }

    private void setLayoutsToHide(LinearLayout lv1, LinearLayout lv2) {
        lv1.setVisibility(View.GONE);
        lv2.setVisibility(View.GONE);
    }

    private void setLayoutsToVisible(LinearLayout lv1, LinearLayout lv2) {
        lv1.setVisibility(View.VISIBLE);
        lv2.setVisibility(View.VISIBLE);
    }

    @Override
    public Loader<Cursor> onCreateLoader(int i, Bundle bundle) {
        String[] projection = {
                PhoneEntry._ID,
                PhoneEntry.COLUMN_PHONE_NAME,
                PhoneEntry.COLUMN_PHONE_PRICE,
                PhoneEntry.COLUMN_PHONE_QUANTITY,
                PhoneEntry.COLUMN_PHONE_REMAINING,
                PhoneEntry.COLUMN_SUPPLIER_EMAIL,
                PhoneEntry.COLUMN_IMAGE_PATH};

        // This loader will execute the ContentProvider's query method on a background thread
        return new CursorLoader(this,   // Parent activity context
                mCurrentPhoneUri,         // Query the content URI for the current phone
                projection,             // Columns to include in the resulting Cursor
                null,                   // No selection clause
                null,                   // No selection arguments
                null);                  // Default sort order
    }

    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor cursor) {
        if (cursor == null || cursor.getCount() < 1) {
            return;
        }
        if (cursor.moveToFirst()) {
            // Find the columns of phone attributes that we're interested in
            int nameColumnIndex = cursor.getColumnIndex(PhoneEntry.COLUMN_PHONE_NAME);
            int priceColumnIndex = cursor.getColumnIndex(PhoneEntry.COLUMN_PHONE_PRICE);
            int quantityColumnIndex = cursor.getColumnIndex(PhoneEntry.COLUMN_PHONE_QUANTITY);
            int amountSoldColumnIndex = cursor.getColumnIndex(PhoneEntry.COLUMN_PHONE_REMAINING);
            int imageColumnIndex = cursor.getColumnIndex(PhoneEntry.COLUMN_IMAGE_PATH);
            int emailColumnIndex = cursor.getColumnIndex(PhoneEntry.COLUMN_SUPPLIER_EMAIL);

            // Extract out the value from the Cursor for the given column index
            phoneName = cursor.getString(nameColumnIndex);
            double phonePrice = cursor.getDouble(priceColumnIndex);
             phoneQuantity = cursor.getInt(quantityColumnIndex);
            int phoneQuantitySold = cursor.getInt(amountSoldColumnIndex);
            String imageUriString = cursor.getString(imageColumnIndex);
            supplierEmail = cursor.getString(emailColumnIndex);

            String displayPrice = Double.toString(phonePrice);
            String displayQuantity = Integer.toString(phoneQuantity);
            String displayQuantitySold = Integer.toString(phoneQuantitySold);

            // Update the views on the screen with the values from the database
            textViewProductName.setText(phoneName);
            textViewProductPrice.setText(displayPrice);
            textViewProductQty.setText(displayQuantity);
            textViewProductSold.setText(displayQuantitySold);
            imageView.setImageBitmap(getBitmapFromUri(Uri.parse(imageUriString)));
        }
    }

    private void showDeleteConfirmationDialog() {
        // Create an AlertDialog.Builder and set the message, and click listeners
        // for the positive and negative buttons on the dialog.
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(R.string.delete_dialog_msg);
        builder.setPositiveButton(R.string.delete, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                // User clicked the "Delete" button, so delete the phone.
                deletePhone();
            }
        });
        builder.setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                // User clicked the "Cancel" button, so dismiss the dialog
                // and continue editing the phone.
                if (dialog != null) {
                    dialog.dismiss();
                }
            }
        });

        // Create and show the AlertDialog
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

    @Override
    public void onLoaderReset(Loader<Cursor> loader) {
        textViewProductName.setText("");
        textViewProductPrice.setText("");
        textViewProductQty.setText("");
        textViewProductSold.setText("");
        imageView.setImageDrawable(null);
    }

    private Bitmap getBitmapFromUri(Uri uri) {
        ParcelFileDescriptor parcelFileDescriptor = null;
        try {
            parcelFileDescriptor =
                    getContentResolver().openFileDescriptor(uri, "r");
            FileDescriptor fileDescriptor = parcelFileDescriptor.getFileDescriptor();
            Bitmap image = BitmapFactory.decodeFileDescriptor(fileDescriptor);
            parcelFileDescriptor.close();
            return image;
        } catch (Exception e) {
            Log.e(LOG_TAG, "Failed to load image.", e);
            return null;
        } finally {
            try {
                if (parcelFileDescriptor != null) {
                    parcelFileDescriptor.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
                Log.e(LOG_TAG, "Error closing ParcelFile Descriptor");
            }
        }
    }
}
