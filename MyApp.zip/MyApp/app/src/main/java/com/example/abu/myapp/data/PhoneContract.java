package com.example.abu.myapp.data;

import android.content.ContentResolver;
import android.net.Uri;
import android.provider.BaseColumns;

public class PhoneContract {

    //To prevent someone from accidentally instantiating the contract class,
    // give it an empty constructor.
    private PhoneContract() {
    }

    public static final String CONTENT_AUTHORITY = "com.example.abu.myapp";

    /**
     * Use CONTENT_AUTHORITY to create the base of all URI's which apps will use to contact
     * the content provider.
     */
    public static final Uri BASE_CONTENT_URI = Uri.parse("content://" + CONTENT_AUTHORITY);


    public static final String PATH_PHONES = "phones";


    public static final class PhoneEntry implements BaseColumns {

        public static final Uri CONTENT_URI = Uri.withAppendedPath(BASE_CONTENT_URI, PATH_PHONES);

        /**
         * Name of database table for phones
         */
        public final static String TABLE_NAME = "phones";

        /**
         * Unique ID number for the phone (only for use in the database table).
         *
         * Type: INTEGER
         */
        public final static String _ID = BaseColumns._ID;

        /**
         * The MIME type of the {@link #CONTENT_URI} for a list of phones.
         */
        public static final String CONTENT_LIST_TYPE =
                ContentResolver.CURSOR_DIR_BASE_TYPE + "/" + CONTENT_AUTHORITY + "/" + PATH_PHONES;

        /**
         * The MIME type of the {@link #CONTENT_URI} for a single phone.
         */
        public static final String CONTENT_ITEM_TYPE =
                ContentResolver.CURSOR_ITEM_BASE_TYPE + "/" + CONTENT_AUTHORITY + "/" + PATH_PHONES;

        /**
         * The name of the phone
         * Type: TEXT
         */
        public final static String COLUMN_PHONE_NAME = "name";

        /**
         * the price of the phone.
         *
         * Type: REAL
         */
        public final static String COLUMN_PHONE_PRICE = "price";

        /**
         * the quantity of the phone available in stock.
         *
         * Type: INTEGER
         */
        public final static String COLUMN_PHONE_REMAINING = "quantity_remaining";

        /**
         * the quantity of the phone available in stock.
         *
         * Type: INTEGER
         */
        public final static String COLUMN_PHONE_QUANTITY = "quantity";

        /**
         * the email of the phone supplier.
         *
         * Type: TEXT
         */
        public final static String COLUMN_SUPPLIER_EMAIL = "supplier_email";

        /**
         * the path of the phone image.
         *
         * Type: TEXT
         */
        public final static String COLUMN_IMAGE_PATH = "image_path";


    }

}